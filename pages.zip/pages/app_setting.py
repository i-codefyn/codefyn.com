TEMPLATE_EXTENSION = "html"
EMAIL_CC = "codefyn@gmail.com"
